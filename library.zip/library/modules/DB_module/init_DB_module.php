<?php

/**
 * Init file for DataBase module
 * 
 * @version 0.0.1
 */

