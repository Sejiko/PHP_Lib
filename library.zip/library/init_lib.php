<?php

/**
 * Init file
 * 
 * @version 1.2.0
 */

// PRE INIT
require_once 'debug/debug.php';
require_once 'functions.php';
require_once 'utils.php';
requireDir( __DIR__ . '/handlers', true);
require_once 'define.php';





